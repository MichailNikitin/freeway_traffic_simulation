#include "graphics.h"

void game()
{
   cleardevice();
   getch();
}